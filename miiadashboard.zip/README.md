# miiadashboard



<table>
  <tr>
   <td colspan="3" valign="top"><img src="screenshots/miiadiagram.png?xxx" ></td>
  </tr>
  <tr>
    <td>Login Screen </td>
     <td>Main Dashboard</td>
     <td>User Profile</td>
	 
  </tr>
  <tr>
    <td valign="top"><img src="screenshots/dashboardlogin.png" ></td>
    <td valign="top"><img src="screenshots/dashboard-mainpanel.png" ></td>
    <td valign="top"><img src="screenshots/userprofile.png" ></td>
    
  </tr>
 </table>
<table>
  <tr>
	 <td>Vitals Lex Bot</td>
	 <td>Search Provider Lex Bot</td>
	 <td>Sample Email search</td>
	 
  </tr>
  <tr>
    <td valign="top"><img src="screenshots/uservitalsbot.png" ></td>
    <td valign="top"><img src="screenshots/Searchproviderbot.png" ></td>
    <td valign="top"><img src="screenshots/searchresultsemailsample.png" ></td>
  </tr>
 </table>

## AWS Hackathon testing 
```
You can use the following URL to test the application 
by signing up and create a new user 

https://master.d3s7eipwj38e3u.amplifyapp.com/

```

