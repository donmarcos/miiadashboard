module.exports = {
  presets: [
    '@vue/app',
    //'@vue/cli-plugin-babel/presetxxx'
  ]
}
