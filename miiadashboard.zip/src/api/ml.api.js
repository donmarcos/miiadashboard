import {
    httpClient
} from './httpClient';

const BMI_END_POINT = '/predictBMI';
const EMO_END_POINT = '/predictemotion';

// set the new base URL 
var config = {
    baseURL: "http://54.179.135.246:5000",
    timeout: 5000, // indicates, 1000ms ie. 1 second
    headers: {
        'Content-Type': 'multipart/form-data'
    },
    responseType: 'blob'
};

httpClient.defaults.baseURL = 'http://54.179.135.246:5000';
httpClient.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

//httpClient.headers = "Content-Type": "multipart/form-data" ;
// const getTypes = () => httpClient.get(END_POINT);


const getBMI = (file) => httpClient.post(BMI_END_POINT, {
    file
}, config);

const getEmotion = (file) => httpClient.post(EMO_END_POINT, {
    file
}, config);


export {
    getBMI,
    getEmotion
}
