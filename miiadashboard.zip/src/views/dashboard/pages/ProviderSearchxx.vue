<template>
  <v-container
    id="health-check"
    fluid
    tag="section"
  >
     <h1>provider Search Lex bot </h1>

  </v-container>
</template>

<script>
export default {
  //
}
</script>
